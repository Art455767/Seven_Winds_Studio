package com.example.sevenwindsstudio.domain.models

data class MenuItem(
    val id: Int,
    val name: String,
    val imageUrl: String,
    val price: Int
)