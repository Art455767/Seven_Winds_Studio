package com.example.sevenwindsstudio.presentation.map

import android.annotation.SuppressLint
import android.graphics.Point
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import com.google.android.gms.maps.model.CameraPosition
import java.lang.reflect.Modifier

@RequiresApi(Build.VERSION_CODES.N)
@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun MapScreen(
    locations: List<com.sevenwindsstudio.coffeeapp.domain.model.Location>,
    navController: NavController,
) {
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition(Point(55.751574, 37.573856), 10f, 0f, 0f)
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Карта") })
        }
    ) {
        Map(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState,
        ) {
            locations.forEach { location ->
                com.yandex.mapkit.compose.Placemark(
                    point = Point(location.latitude, location.longitude),
                    onClick = { true }
                )
            }
        }
    }
}