package com.example.sevenwindsstudio.presentation.menu

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.FloatingActionButton
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.sevenwindsstudio.presentation.navigation.Screen

@Composable
fun MenuScreen(
    navController: NavController,
    locationId: Int,
    viewModel: MenuViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    LaunchedEffect(locationId) {
        viewModel.loadMenu(locationId)
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Меню кофейни") }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    val selected = viewModel.getSelectedItems()
                    if (selected.isNotEmpty()) {
                        navController.navigate(Screen.Order.route)
                    }
                }
            ) {
                Text("В корзину")
            }
        }
    ) { padding ->
        if (state.isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else if (state.errorMessage != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text(state.errorMessage!!, color = MaterialTheme.colors.error)
            }
        } else {
            LazyColumn(
                contentPadding = padding,
                modifier = Modifier.fillMaxSize()
            ) {
                items(state.items) { item ->
                    MenuItemCard(
                        item = item,
                        onAdd = { viewModel.incrementCount(item.menuItem.id) },
                        onRemove = { viewModel.decrementCount(item.menuItem.id) }
                    )
                }
            }
        }
    }
}