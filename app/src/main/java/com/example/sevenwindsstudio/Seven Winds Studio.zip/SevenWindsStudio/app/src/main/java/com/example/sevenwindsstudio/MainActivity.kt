package com.example.sevenwindsstudio

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.navigation.compose.rememberNavController
import com.example.sevenwindsstudio.presentation.navigation.NavGraph
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

//        MapKitFactory.setApiKey("e348bbbe-609e-4441-957a-40543299ac81")
//        MapKitFactory.initialize(this)

        setContent {
            CoffeeAppTheme {
                val navController = rememberNavController()
                NavGraph(navController)
            }
        }
    }

}
