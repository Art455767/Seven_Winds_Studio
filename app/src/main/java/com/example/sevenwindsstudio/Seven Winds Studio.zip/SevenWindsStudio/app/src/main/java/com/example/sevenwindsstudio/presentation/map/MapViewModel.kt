package com.example.sevenwindsstudio.presentation.map

import androidx.lifecycle.ViewModel
import com.example.sevenwindsstudio.domain.models.Location

class MapViewModel: ViewModel() {
    var locations: List<Location> = emptyList()
        private set

    fun setLocations(locs: List<Location>) {
        locations = locs
    }
}