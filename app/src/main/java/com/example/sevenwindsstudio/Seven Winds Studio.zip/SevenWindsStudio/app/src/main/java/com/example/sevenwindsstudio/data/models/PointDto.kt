package com.example.sevenwindsstudio.data.models

data class PointDto(
    val latitude: Double,
    val longitude: Double
)