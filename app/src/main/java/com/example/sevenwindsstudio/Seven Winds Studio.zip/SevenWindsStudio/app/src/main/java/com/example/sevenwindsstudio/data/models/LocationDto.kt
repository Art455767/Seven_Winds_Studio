package com.example.sevenwindsstudio.data.models

data class LocationDto(
    val id: Int,
    val name: String,
    val point: PointDto
)