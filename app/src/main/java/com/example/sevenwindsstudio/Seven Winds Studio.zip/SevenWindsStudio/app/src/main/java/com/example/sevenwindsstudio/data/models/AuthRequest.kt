package com.example.sevenwindsstudio.data.models

data class AuthRequest(
    val login: String,
    val password: String
)