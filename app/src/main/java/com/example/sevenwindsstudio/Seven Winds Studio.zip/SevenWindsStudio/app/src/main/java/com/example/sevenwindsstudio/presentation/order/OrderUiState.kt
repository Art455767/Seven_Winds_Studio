package com.example.sevenwindsstudio.presentation.order

import com.example.sevenwindsstudio.presentation.menu.MenuItemWithCount

data class OrderUiState(
    val items: List<MenuItemWithCount> = emptyList(),
    val totalPrice: Int = 0,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)