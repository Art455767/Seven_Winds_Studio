package com.example.sevenwindsstudio.presentation.navigation

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.sevenwindsstudio.presentation.locations.LocationsScreen
import com.example.sevenwindsstudio.presentation.login.LoginScreen
import com.example.sevenwindsstudio.presentation.map.MapScreen
import com.example.sevenwindsstudio.presentation.menu.MenuScreen
import com.example.sevenwindsstudio.presentation.order.OrderScreen
import com.example.sevenwindsstudio.presentation.register.RegisterScreen

@RequiresApi(Build.VERSION_CODES.N)
@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Screen.Register.route) {

        composable(Screen.Register.route) {
            RegisterScreen(navController)
        }

        composable(Screen.Login.route) {
            LoginScreen(navController)
        }

        composable(Screen.Locations.route) {
            LocationsScreen(navController)
        }

        composable(Screen.Map.route) {
            MapScreen(navController)
        }

        composable(Screen.Menu.route,
            arguments = listOf(
                androidx.navigation.navArgument("locationId") {
                    type = androidx.navigation.NavType.IntType
                }
            )
        ) { backStackEntry ->
            val locationId = backStackEntry.arguments?.getInt("locationId") ?: 0
            MenuScreen(navController, locationId)
        }

        composable(Screen.Order.route) {
            OrderScreen(navController)
        }
    }
}