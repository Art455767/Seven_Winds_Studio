package com.example.sevenwindsstudio.data.di

import com.example.sevenwindsstudio.domain.useCase.GetLocationsUseCase
import com.example.sevenwindsstudio.domain.useCase.GetMenuUseCase
import com.example.sevenwindsstudio.domain.useCase.LoginUseCase
import com.example.sevenwindsstudio.domain.useCase.RegisterUseCase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
object UseCaseModule {

    @Provides
    fun provideLoginUseCase(repository: com.sevenwindsstudio
        .coffeeapp
        .domain
        .repository
        .CoffeeRepository): LoginUseCase = LoginUseCase(repository)

    @Provides
    fun provideRegisterUseCase(repository: com.sevenwindsstudio
        .coffeeapp
        .domain
        .repository
        .CoffeeRepository): RegisterUseCase = RegisterUseCase(repository)

    @Provides
    fun provideGetLocationsUseCase(repository: com.sevenwindsstudio
        .coffeeapp
        .domain
        .repository
        .CoffeeRepository): GetLocationsUseCase = GetLocationsUseCase(repository)

    @Provides
    fun provideGetMenuUseCase(repository: com.sevenwindsstudio
        .coffeeapp
        .domain
        .repository
        .CoffeeRepository): GetMenuUseCase = GetMenuUseCase(repository)
}