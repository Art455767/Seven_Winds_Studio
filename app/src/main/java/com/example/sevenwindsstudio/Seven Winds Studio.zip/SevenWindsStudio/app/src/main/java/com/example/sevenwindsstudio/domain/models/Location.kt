package com.example.sevenwindsstudio.domain.models

data class Location(
    val id: Int,
    val name: String,
    val latitude: Double,
    val longitude: Double
) {
    companion object {
        fun distanceBetween(
            lat1: Double, lon1: Double, lat2: Double, lon2: Double, results: FloatArray) {

        }
    }
}