package com.example.sevenwindsstudio.domain.useCase

import com.example.sevenwindsstudio.domain.models.AuthToken
import com.example.sevenwindsstudio.domain.repository.CoffeeRepository
import javax.inject.Inject

class LoginUseCase @Inject constructor(
    private val repository: CoffeeRepository
) {
    suspend operator fun invoke(login: String, password: String): Result<AuthToken> {
        return repository.login(login, password)
    }
}