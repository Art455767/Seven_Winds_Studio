package com.example.sevenwindsstudio.presentation.order

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.sevenwindsstudio.presentation.menu.MenuItemWithCount
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class OrderViewModel @Inject constructor() : ViewModel() {

    private val _uiState = MutableStateFlow(OrderUiState())
    val uiState: StateFlow<OrderUiState> = _uiState

    fun setOrderItems(items: List<MenuItemWithCount>) {
        val total = items.sumOf { it.menuItem.price * it.count }
        _uiState.value = OrderUiState(items = items, totalPrice = total)
    }

    fun payOrder() {
        viewModelScope.launch {
            // Здесь реализуйте логику оплаты
            _uiState.value = _uiState.value.copy(isLoading = true)

            // После оплаты
            _uiState.value = _uiState.value.copy(
                isLoading = false,
                errorMessage = null,
                items = emptyList(),
                totalPrice = 0
            )
        }
    }
}