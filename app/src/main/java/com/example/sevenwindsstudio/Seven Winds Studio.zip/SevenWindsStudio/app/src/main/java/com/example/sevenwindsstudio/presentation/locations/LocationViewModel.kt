package com.example.sevenwindsstudio.presentation.locations

import android.annotation.SuppressLint
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sevenwindsstudio.domain.useCase.GetLocationsUseCase
import com.example.sevenwindsstudio.utils.distanceBetween
import com.google.android.gms.location.LocationServices
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

@HiltViewModel
class LocationsViewModel @Inject constructor(
    private val getLocationsUseCase: GetLocationsUseCase,
    application: Application
) : AndroidViewModel(application) {

    private val fusedLocationClient = LocationServices.getFusedLocationProviderClient(application)

    private val _uiState = MutableStateFlow(LocationsUiState(isLoading = true))
    val uiState: StateFlow<LocationsUiState> = _uiState

    @SuppressLint("MissingPermission")
    fun loadLocations() {
        viewModelScope.launch {
            _uiState.value = LocationsUiState(isLoading = true)
            try {
                val userLocation = fusedLocationClient.lastLocation.await()
                if (userLocation == null) {
                    _uiState.value = LocationsUiState(error = "Cannot get current location")
                    return@launch
                }
                val result = getLocationsUseCase()
                if (result.isSuccess) {
                    val locations = result.getOrDefault(emptyList())
                    val withDistance = locations.map { location ->
                        val distanceMeters = distanceBetween(
                            userLocation.latitude,
                            userLocation.longitude,
                            location.latitude,
                            location.longitude
                        )
                        val distanceStr = if (distanceMeters < 1000) {
                            "${distanceMeters.toInt()} м от вас"
                        } else {
                            "${(distanceMeters / 1000).format(1)} км от вас"
                        }

                        LocationItem(location = location, distance = distanceStr)
                    }
                    _uiState.value = LocationsUiState(locations = withDistance)
                } else {
                    _uiState.value = LocationsUiState(error = result.exceptionOrNull()?.message)
                }
            } catch (e: Exception) {
                _uiState.value = LocationsUiState(error = e.message ?: "Error loading locations")
            }
        }
    }
}

fun Double.format(digits: Int) = "%.${digits}f".format(this)